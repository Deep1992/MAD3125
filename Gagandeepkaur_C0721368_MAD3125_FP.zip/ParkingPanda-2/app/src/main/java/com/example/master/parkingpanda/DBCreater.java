package com.example.master.parkingpanda;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by master on 2018-04-13.
 */

public class DBCreater extends SQLiteOpenHelper {
    private final static String DB_NAME = "ParkingDB";
    private final static String TB_NAME_USER = "UserInfo";
    private final static String  TB_NAME_USERS = "user";


    public DBCreater(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        try {
            String CREATE_TABLE = "CREATE TABLE " +
                    TB_NAME_USER + " (Id INTEGER AUTO_INCREMENT," +
                    "Name VARCHAR(100), Phone VARCHAR(30)," +
                    "Email VARCHAR(100) PRIMARY KEY, " +
                    "Password VARCHAR(30)," +
                    "Address VARCHAR(10) , City VARCHAR(10), Carplate VARCHAR(20))" ;
            Log.v("On create table : ",CREATE_TABLE);

            db.execSQL(CREATE_TABLE);


        }catch (Exception e){
            Log.e("DBCreater",e.getMessage());
        }
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_USER);
            onCreate(db);
        }catch (Exception e){
            Log.e("DBCreater",e.getMessage());

        }

    }
}
