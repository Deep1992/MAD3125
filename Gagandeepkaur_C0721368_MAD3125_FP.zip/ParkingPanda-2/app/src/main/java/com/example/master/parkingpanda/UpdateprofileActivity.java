package com.example.master.parkingpanda;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateprofileActivity extends AppCompatActivity implements View.OnClickListener{
    EditText edtUpdatename,edtUpdateemail,edtUpdatecontact,edtUpdateaddress,edtUpdatecity,edtUpdatecarplate,edtUpdatepassword;
    DBParking dbHelper;
    SQLiteDatabase pandaDB;
    String data;
    Button btnsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateprofile);

        SharedPreferences sp = getSharedPreferences("com.example.master.parkingpanda.shared", Context.MODE_PRIVATE);
        data = sp.getString("username","Data Missing");
        edtUpdatename = (EditText)findViewById(R.id.edt_updatename);
       // edtUpdateemail = (EditText)findViewById(R.id.edt_updateemail);
        edtUpdatecontact = (EditText)findViewById(R.id.edt_updatecontact);
        edtUpdateaddress = (EditText)findViewById(R.id.edt_updateaddress);
        edtUpdatecity = (EditText)findViewById(R.id.edt_updatecity);
        edtUpdatecarplate = (EditText)findViewById(R.id.edt_updatecarplate);
        edtUpdatepassword = (EditText)findViewById(R.id.edt_updatepassword);
        btnsubmit = (Button)findViewById(R.id.btn_submit);
        btnsubmit.setOnClickListener(this);
        dbHelper = new DBParking(this);
        displayData();
    }

    private void displayData() {
        try {
            pandaDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Email", "Phone", "Password","Address","City","Carplate"};
            Cursor cursor = pandaDB.query("UserInfo", columns, "Email = ?", new String[]{data}, null, null, null);
            while (cursor.moveToNext()) {
                edtUpdatename.setText(cursor.getString(cursor.getColumnIndex("Name")));
               // edtUpdateemail.setText(cursor.getString(cursor.getColumnIndex("Email")));
                edtUpdatecontact.setText(cursor.getString(cursor.getColumnIndex("Phone")));
                edtUpdatepassword.setText(cursor.getString(cursor.getColumnIndex("Password")));

                edtUpdateaddress.setText(cursor.getString(cursor.getColumnIndex("Address")));
                edtUpdatecity.setText(cursor.getString(cursor.getColumnIndex("City")));
                edtUpdatecarplate.setText(cursor.getString(cursor.getColumnIndex("Carplate")));

            }
        } catch (Exception e) {
            Log.e("UpdateprofileActivity", "Unable to fetch the records");
        }
        pandaDB.close();
    }

    private void updateData(){
        String name = edtUpdatename.getText().toString();
       // String email = edtUpdateemail.getText().toString();
        String userpassword = edtUpdatepassword.getText().toString();
        String contact = edtUpdatecontact.getText().toString();
        String address = edtUpdateaddress.getText().toString();
        String city = edtUpdatecity.getText().toString();
        String carplate = edtUpdatecarplate.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
       // cv.put("Email",email);
        cv.put("Phone",contact);
        cv.put("Password",userpassword);
        cv.put("Address",address);
        cv.put("City",city);
        cv.put("Carplate",carplate);
        try{
            pandaDB = dbHelper.getWritableDatabase();
            pandaDB.update("UserInfo",cv,"Email = ?",new String[]{data});
            Log.v("Update record","Successful");
        }catch (Exception e){
            Log.e("Update User",e.getMessage());
        }
        pandaDB.close();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnsubmit.getId()){
            updateData();
            Toast.makeText(this,"Profile has been update succssfully",Toast.LENGTH_LONG).show();
            Intent loginintent = new Intent(this,UserprofileActivity.class);
            startActivity(loginintent);
        }

    }
}
