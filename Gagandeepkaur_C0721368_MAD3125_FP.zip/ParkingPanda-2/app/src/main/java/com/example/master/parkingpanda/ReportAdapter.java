package com.example.master.parkingpanda;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by master on 2018-04-16.
 */

public class ReportAdapter extends BaseAdapter{

    //LayoutInflater inflater;
    Context context;
   private List<Product> mProductList;

    public ReportAdapter(Context context, List<Product> mProductList) {
        this.context = context;
        this.mProductList = mProductList;
    }

    DBParking dbHelper;
    SQLiteDatabase pandaDB;



    @Override
    public int getCount() {
        return mProductList.size();
    }

    @Override
    public Object getItem(int position) {
        return mProductList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View v = View.inflate(context,R.layout.list_receipt_item,null);



        TextView company = (TextView) v.findViewById(R.id.txt_listcompany);
        TextView amount = (TextView) v.findViewById(R.id.txt_listamount);
        TextView lot = (TextView) v.findViewById(R.id.txt_listlot);
        TextView spot = (TextView) v.findViewById(R.id.txt_listspot);
        TextView carPlate = (TextView) v.findViewById(R.id.txt_listplate);
        TextView dateTime = (TextView) v.findViewById(R.id.txt_listdate);
        TextView hours = (TextView) v.findViewById(R.id.txt_listhours);
        TextView method = (TextView) v.findViewById(R.id.txt_listmethod);
        TextView color = (TextView) v.findViewById(R.id.txt_listcolor);
        TextView id = (TextView) v.findViewById(R.id.txt_id);

        carPlate.setText(mProductList.get(position).getCarplate());
        company.setText(mProductList.get(position).getCarcompany());
        color.setText(mProductList.get(position).getCarcolor());
        lot.setText(mProductList.get(position).getLot());
        spot.setText(mProductList.get(position).getSpot());
        hours.setText(mProductList.get(position).getHour());
        amount.setText(mProductList.get(position).getAmount());
        dateTime.setText(mProductList.get(position).getDate());
        method.setText(mProductList.get(position).getMethod());
        id.setText(String.valueOf(mProductList.get(position).getId()));


        






        return v;
    }



}
