package com.example.master.parkingpanda;

/**
 * Created by master on 2018-04-17.
 */

public class Product {
    String carplate,carcompany,carcolor,lot,spot,hour,amount,method,date;
    int id;
    public Product(String carplate, String carcompany, String carcolor, String lot, String spot, String hour, String amount, String method, String date,int id) {
        this.carplate = carplate;
        this.carcompany = carcompany;
        this.carcolor = carcolor;
        this.lot = lot;
        this.spot = spot;
        this.hour = hour;
        this.amount = amount;
        this.method = method;
        this.date = date;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarplate() {
        return carplate;
    }

    public void setCarplate(String carplate) {
        this.carplate = carplate;
    }

    public String getCarcompany() {
        return carcompany;
    }

    public void setCarcompany(String carcompany) {
        this.carcompany = carcompany;
    }

    public String getCarcolor() {
        return carcolor;
    }

    public void setCarcolor(String carcolor) {
        this.carcolor = carcolor;
    }

    public String getLot() {
        return lot;
    }

    public void setLot(String lot) {
        this.lot = lot;
    }

    public String getSpot() {
        return spot;
    }

    public void setSpot(String spot) {
        this.spot = spot;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
