package com.example.master.parkingpanda;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView txtnavHeaderName,txtnavHeaderEmail;
    String data;
    private  long START_TIME_IN_MILLIS = 0;
    TextView mTextViewCountDown;
    CountDownTimer countDownTimer;
    Boolean mTimerRunning;
    long mTimeLeftInMillis = START_TIME_IN_MILLIS;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                        Uri.parse("smsto:4163195756"));
                smsIntent.putExtra("sms_body", "Test message");

                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.SEND_SMS) !=
                        PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(),
                            "SMS permission denied", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivity(smsIntent);


            }
        });

        FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");

                emailIntent.putExtra(Intent.EXTRA_EMAIL,
                        new String[]{"kamaldeepk46@gmail.com"});

                emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                        "Test Email");
                emailIntent.putExtra(Intent.EXTRA_TEXT,
                        "This is a test message");

                emailIntent.setType("message/rfc822");

                startActivity(Intent.createChooser(emailIntent,
                        "Select Email Client"));


            }
        });
        FloatingActionButton fab2 = (FloatingActionButton) findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:4163195756"));

                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.CALL_PHONE) !=
                        PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(),
                            "Call permission denied", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivity(callIntent);


            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        SharedPreferences sp = getSharedPreferences("com.example.master.parkingpanda.shared", Context.MODE_PRIVATE);
        data = sp.getString("username", "Data Missing");

        View headerView = navigationView.getHeaderView(0);
        txtnavHeaderName = (TextView) headerView.findViewById(R.id.txt_nav_header_name);
        // txtnavHeaderEmail = (TextView)findViewById(R.id.txt_nav_header_email);
        txtnavHeaderName.setText(data);

        SharedPreferences sp1 = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
        String hours = sp1.getString("totalhour", "Data Missing");
        mTextViewCountDown = findViewById(R.id.txt_timer);
         if(hours == "Data Missing"){
          mTimeLeftInMillis = 0;
    }else if(hours == "one hour"){
            mTimeLeftInMillis = 3600000;
        }else if(hours == "two hours"){
            mTimeLeftInMillis = 7200000;
        }else if(hours == "three hours"){
            mTimeLeftInMillis = 10800000;
        }else if(hours == "12 hours"){
            mTimeLeftInMillis = 43200000;
        }
        startTimer();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_receipt) {
            Intent receiptIntent = new Intent(this,ReceiptActivity.class);
            startActivity(receiptIntent);
        } else if (id == R.id.nav_location) {
            Intent locationIntent = new Intent(this,LocationActivity.class);
            startActivity(locationIntent);

        } else if (id == R.id.nav_report) {
            Intent reportIntent = new Intent(this,ReportlistActivity.class);
            startActivity(reportIntent);

        } else if (id == R.id.nav_manual) {
            Intent manualIntent = new Intent(this,ManualActivity.class);
            startActivity(manualIntent);

        } else if (id == R.id.nav_profile) {
            Intent profileIntent = new Intent(this,UserprofileActivity.class);
            startActivity(profileIntent);

        } else if (id == R.id.nav_support) {
            Intent supportIntent = new Intent(this,SupportActivity.class);
            startActivity(supportIntent);

        }else if (id == R.id.nav_logout) {
            finish();
            Intent loginIntent = new Intent(this,LoginActivity.class);
            startActivity(loginIntent);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private void startTimer(){
        countDownTimer = new CountDownTimer(mTimeLeftInMillis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();

            }

            @Override
            public void onFinish() {

            }
        }.start();
    }
    public void updateCountDownText(){
        int minutes = (int) mTimeLeftInMillis /1000 /60;
        int seconds = (int) mTimeLeftInMillis /1000 % 60;
        String timeLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        mTextViewCountDown.setText(timeLeftFormatted);

    }
}
