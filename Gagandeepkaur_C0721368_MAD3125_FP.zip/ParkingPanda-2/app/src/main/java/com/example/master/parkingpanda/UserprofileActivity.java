package com.example.master.parkingpanda;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class UserprofileActivity extends AppCompatActivity implements View.OnClickListener{
    TextView profileUserName,profileUserEmail,profileUserContact,profileUserAddress,profileUserCity,profileUserCarPlate;
    DBParking dbHelper;
    SQLiteDatabase pandaDB;
    String data;
    Button btnupdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        SharedPreferences sp = getSharedPreferences("com.example.master.parkingpanda.shared", Context.MODE_PRIVATE);
         data = sp.getString("username","Data Missing");

        profileUserName = (TextView)findViewById(R.id.txt_profile_username);
        profileUserEmail = (TextView)findViewById(R.id.txt_profile_useremail);
        profileUserContact = (TextView)findViewById(R.id.txt_profile_usercontact);
        profileUserAddress = (TextView)findViewById(R.id.txt_profile_useraddress);
        profileUserCity = (TextView)findViewById(R.id.txt_profile_usercity);
        profileUserCarPlate = (TextView)findViewById(R.id.txt_profile_usercarplate);
        btnupdate = (Button)findViewById(R.id.btn_update);
        btnupdate.setOnClickListener(this);

        dbHelper = new DBParking(this);
        displayData();
    }



    private void displayData() {
    try {
        pandaDB = dbHelper.getReadableDatabase();
        String columns[] = {"Name", "Email", "Phone", "Password","Address","City","Carplate"};
        Cursor cursor = pandaDB.query("UserInfo", columns, "Email = ?", new String[]{data}, null, null, null);
        while (cursor.moveToNext()) {
            profileUserName.setText(cursor.getString(cursor.getColumnIndex("Name")));
            profileUserEmail.setText(cursor.getString(cursor.getColumnIndex("Email")));
            profileUserContact.setText(cursor.getString(cursor.getColumnIndex("Phone")));

            profileUserAddress.setText(cursor.getString(cursor.getColumnIndex("Address")));
            profileUserCity.setText(cursor.getString(cursor.getColumnIndex("City")));
            profileUserCarPlate.setText(cursor.getString(cursor.getColumnIndex("Carplate")));

        }
    } catch (Exception e) {
        Log.e("RegisterActivity", "Unable to fetch the records");
    }
    pandaDB.close();
}

    @Override
    public void onClick(View view) {
        if(view.getId() == btnupdate.getId()){
            Intent updateIntent = new Intent(this,UpdateprofileActivity.class);
            startActivity(updateIntent);
        }

    }
}
