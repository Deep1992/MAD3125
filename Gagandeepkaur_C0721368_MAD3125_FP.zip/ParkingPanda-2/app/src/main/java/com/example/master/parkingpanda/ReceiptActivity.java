package com.example.master.parkingpanda;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class ReceiptActivity extends AppCompatActivity implements View.OnClickListener ,AdapterView.OnItemSelectedListener{

    EditText edt_carpalte,edt_carcolor,edt_cardnumber,edt_cvc;
    TextView txt_datetime,txt_amount;
    Spinner spin_carcompany,spin_lot,spin_spot,spin_paymentmethod;
    RadioButton rdo_one,rdo_two,rdo_three,rdo_endofday;
    RadioGroup rdo_hours;
    int parkingRate[] = {5,10,20,35};
    String lots[]={"A","B","C","D","E"};
    String spots[] = {"1","2","3","4","5"};
    String paymentMethods[] = {"Debit", "Visa", "Master", "American Express"};
    String companyNames[]={"BMW","Audi","Mercedes","Jaguar","Chrysler"};
    int logos[] = {R.drawable.bmw,R.drawable.audi,R.drawable.mercedes,R.drawable.jaguar,R.drawable.chrysler};
    ImageView img_carlogo;

    Button btnpay;

    String lot, spot, carPlate, payment, dateTime, company,color,totalhour,amount;
    //int amount;
    DBParking dbHelper;
    SQLiteDatabase pandaDB;
    PopupWindow popupWindow;
    LayoutInflater layoutInflater;
    RelativeLayout relativeLayout;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        relativeLayout = (RelativeLayout)findViewById(R.id.receipt_relative);
        rdo_one = (RadioButton)findViewById(R.id.rdo_onehour);
        rdo_one.setOnClickListener(this);

        rdo_two = (RadioButton)findViewById(R.id.rdo_twohour);
        rdo_two.setOnClickListener(this);

        rdo_three = (RadioButton)findViewById(R.id.rdo_threehour);
        rdo_three.setOnClickListener(this);

        rdo_endofday = (RadioButton)findViewById(R.id.rdo_endofday);
        rdo_endofday.setOnClickListener(this);

        rdo_hours = (RadioGroup)findViewById(R.id.rdo_hours);

        img_carlogo = (ImageView) findViewById(R.id.img_carlogo);

        edt_carpalte = (EditText)findViewById(R.id.edt_receiptcarplate);

        edt_carcolor = (EditText)findViewById(R.id.edt_carcolor);

        edt_cardnumber = (EditText)findViewById(R.id.edt_cardnumber);

        edt_cvc = (EditText)findViewById(R.id.edt_cvc);

        txt_datetime = (TextView)findViewById(R.id.txt_datetime);
        Date dt = Calendar.getInstance().getTime();

        txt_datetime.setText(dt.toString());

        txt_amount = (TextView)findViewById(R.id.txt_amount);
        txt_amount.setText("$" + String.valueOf(parkingRate[0]));

        spin_carcompany = (Spinner)findViewById(R.id.spin_carcompany);
        ArrayAdapter adaptcompany = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                companyNames);
        adaptcompany.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spin_carcompany.setAdapter(adaptcompany);
        spin_carcompany.setOnItemSelectedListener(this);

        spin_lot = (Spinner)findViewById(R.id.spin_lot);
        ArrayAdapter adaptLot = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                lots);
        adaptLot.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spin_lot.setAdapter(adaptLot);
        spin_lot.setOnItemSelectedListener(this);

        spin_spot = (Spinner)findViewById(R.id.spin_spot);
        ArrayAdapter adaptSpot = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                spots);
        adaptSpot.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spin_spot.setAdapter(adaptSpot);
        spin_spot.setOnItemSelectedListener(this);

        spin_paymentmethod = (Spinner)findViewById(R.id.spin_paymentmethod);
        ArrayAdapter adaptPayment = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                paymentMethods);
        adaptPayment.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spin_paymentmethod.setAdapter(adaptPayment);
        spin_paymentmethod.setOnItemSelectedListener(this);
        btnpay = (Button)findViewById(R.id.btn_pay);
        btnpay.setOnClickListener(this);

        dbHelper = new DBParking(this);


    }

    @Override
    public void onClick(View view) {

        if (rdo_one.isChecked()){
            txt_amount.setText("$" + String.valueOf(parkingRate[0]));
        }else if (rdo_two.isChecked()){
            txt_amount.setText("$" + String.valueOf(parkingRate[1]));
        }else if (rdo_three.isChecked()){
            txt_amount.setText("$" + String.valueOf(parkingRate[2]));
        }else if (rdo_endofday.isChecked()){
            txt_amount.setText("$" + String.valueOf(parkingRate[3]));
        }
        if(spin_carcompany.getSelectedItem() == "BMW"){
            img_carlogo.setImageResource(R.drawable.bmw);

        } else if(spin_carcompany.getSelectedItem() == "Audi"){
            img_carlogo.setImageResource(R.drawable.audi);

        }else if(spin_carcompany.getSelectedItem() == "Jaguar"){
            img_carlogo.setImageResource(R.drawable.jaguar);

        } else if(spin_carcompany.getSelectedItem() == "Mercedes"){
            img_carlogo.setImageResource(R.drawable.mercedes);

        } else if(spin_carcompany.getSelectedItem() == "Chrysler"){
            img_carlogo.setImageResource(R.drawable.chrysler);

        }
        if(view.getId() == btnpay.getId()){

            insertData();
            displayData();
            carPlate = edt_carpalte.getText().toString();
             company = spin_carcompany.getSelectedItem().toString();
             color = edt_carcolor.getText().toString();
            if (rdo_one.isChecked()){
                totalhour = "one hour";

            }else if (rdo_two.isChecked()){
                totalhour = "two hours";
            }else if (rdo_three.isChecked()){
                totalhour = "three hours";
            }else if (rdo_endofday.isChecked()){
                totalhour = "12 hours";
            }

             lot = spin_lot.getSelectedItem().toString();
            spot = spin_spot.getSelectedItem().toString();
             dateTime = txt_datetime.getText().toString();
             amount = txt_amount.getText().toString();

             payment = spin_paymentmethod.getSelectedItem().toString();

            SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("CarPlate",carPlate);
            edit.putString("Company",company);
            edit.putString("Amount",amount);
            edit.putString("DateTime",dateTime);
            edit.putString("Lot",lot);
            edit.putString("Spot",spot);
            edit.putString("Payment",payment);
            edit.putString("color",color);
            edit.putString("totalhour",totalhour);


            edit.commit();
//            layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);
//            ViewGroup container = (ViewGroup) layoutInflater.inflate(R.layout.activity_report,null);
//            popupWindow = new PopupWindow(container,800,800,true);
//            popupWindow.showAtLocation(relativeLayout, Gravity.NO_GRAVITY,500,500);
//
//            container.setOnTouchListener(new View.OnTouchListener() {
//                @Override
//                public boolean onTouch(View view, MotionEvent motionEvent) {
//                    popupWindow.dismiss();
//                    return true;
//                }
//            });

            Intent reportIntent = new Intent(getApplicationContext(),ReportActivity.class);
            startActivity(reportIntent);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

        if (adapterView.getId() == spin_lot.getId()){

            lot = lots[position];
        }else if (adapterView.getId() == spin_spot.getId()){

            spot = spots[position];
        }else if (adapterView.getId() == spin_paymentmethod.getId()){
            payment = paymentMethods[position];
        }else if (adapterView.getId() == spin_carcompany.getId()){
            company = companyNames[position];

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void insertData(){
        String carplate = edt_carpalte.getText().toString();
        String carcompany = spin_carcompany.getSelectedItem().toString();
        String carcolor = edt_carcolor.getText().toString();
        String noofhour = "one hour";
        if (rdo_one.isChecked()){
            noofhour = "one hour";

        }else if (rdo_two.isChecked()){
            noofhour = "two hours";
        }else if (rdo_three.isChecked()){
            noofhour = "three hours";
        }else if (rdo_endofday.isChecked()){
            noofhour = "12 hours";
        }

        String lott = spin_lot.getSelectedItem().toString();
        String spot = spin_spot.getSelectedItem().toString();
        String datetime = txt_datetime.getText().toString();
        String amount = txt_amount.getText().toString();
        String cardnumber = edt_cardnumber.getText().toString();
        String cvc = edt_cvc.getText().toString();
        String payment = spin_paymentmethod.getSelectedItem().toString();
        ContentValues cv = new ContentValues();
        cv.put("Carplatenumber",carplate);
        cv.put("Carcompany",carcompany);
        cv.put("Carcolor",carcolor);
        cv.put("Noofhour",noofhour);
        cv.put("Lot",lott);
        cv.put("Spot",spot);
        cv.put("Datetime",datetime);
        cv.put("Amount",amount);
        cv.put("Cardnumber",cardnumber);
        cv.put("Cvc",cvc);
        cv.put("Payment",payment);
        try{
            pandaDB = dbHelper.getWritableDatabase();
            pandaDB.insert("Receipt",null,cv);
            Log.v("Insert record","Successful");
        }catch (Exception e){
            Log.e("Insert User",e.getMessage());
        }
        pandaDB.close();
    }

    private void displayData(){
        try{
            pandaDB = dbHelper.getReadableDatabase();
            String columns[] = {"Carplatenumber","Carcompany","Carcolor","Noofhour","Lot","Spot","Datetime","Amount",
            "Cardnumber","Cvc","Payment"};
            Cursor cursor = pandaDB.query("Receipt",columns,null,null,null,null,null);
            while (cursor.moveToNext()){
                String carplate = cursor.getString(cursor.getColumnIndex("Carplatenumber"));
                String company = cursor.getString(cursor.getColumnIndex("Carcompany"));
                String color = cursor.getString(cursor.getColumnIndex("Carcolor"));
                String hour = cursor.getString(cursor.getColumnIndex("Noofhour"));
                String lot = cursor.getString(cursor.getColumnIndex("Lot"));
                String spot = cursor.getString(cursor.getColumnIndex("Spot"));
                String date = cursor.getString(cursor.getColumnIndex("Datetime"));
                String amount = cursor.getString(cursor.getColumnIndex("Amount"));
                String card = cursor.getString(cursor.getColumnIndex("Cardnumber"));
                String cvc = cursor.getString(cursor.getColumnIndex("Cvc"));
                String payment = cursor.getString(cursor.getColumnIndex("Payment"));
                String userInfo = carplate + "\n" + company + "\n" + color + "\n" + hour + "\n" + lot
                        + "\n" + spot + "\n" + date + "\n" + amount + "\n" + card + "\n" +  cvc + "\n" + payment;
                Toast.makeText(this,"Confirm your Receipt",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            Log.e("ReceiptActivity","Unable to fetch the records");
        }
        pandaDB.close();
    }
}
