package com.example.master.parkingpanda;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by master on 2018-04-13.
 */

public class DBParking extends SQLiteOpenHelper {
    private final static String DB_NAME = "PandaDB";
    private final static String TB_NAME_USER = "UserInfo";
    private final static String TB_NAME_RECEIPT = "Receipt";
    public DBParking(Context context) {
        super(context, DB_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String CREATE_TABLE = "CREATE TABLE " +
                    TB_NAME_USER + " (Id INTEGER AUTO_INCREMENT," +
                    "Name VARCHAR(30), Phone VARCHAR(30)," +
                    "Email VARCHAR(50) PRIMARY KEY, " +
                    "Password VARCHAR(30)," +
                    "Address VARCHAR(10) , City VARCHAR(10), Carplate VARCHAR(20))";
            Log.v("On create table : ", CREATE_TABLE);

            db.execSQL(CREATE_TABLE);



                String CREATE_TABLE_RECEIPT = "CREATE TABLE " +
                        TB_NAME_RECEIPT + "(Id INTEGER AUTO_INCREMENT , " +
                        "Carplatenumber VARCHAR(30), Carcompany VARCHAR(30)," +
                        "Carcolor VARCHAR(30), Noofhour VARCHAR(30)," +
                        "Amount VARCHAR(30),Lot VARCHAR(20)," +
                        "Spot VARCHAR(20),Datetime VARCHAR(30)," +
                        "Payment VARCHAR(30),Cardnumber VARCHAR(30)," +
                        "Cvc VARCHAR(20))";
                Log.v("On create table : ", CREATE_TABLE_RECEIPT);

                db.execSQL(CREATE_TABLE_RECEIPT);



        }catch (Exception e) {
                Log.e("DBCreater", e.getMessage());
            }


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_USER);

            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_RECEIPT);
            onCreate(db);
        }catch (Exception e){
            Log.e("DBParking",e.getMessage());

        }

    }
}
