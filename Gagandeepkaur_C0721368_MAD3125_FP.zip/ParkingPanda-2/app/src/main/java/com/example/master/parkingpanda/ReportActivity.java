package com.example.master.parkingpanda;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ReportActivity extends AppCompatActivity implements View.OnClickListener{

    TextView txt_plate,txt_company,txt_color,txt_lot,txt_spot,txt_hours,txt_amount,txt_payment,txt_date;
    Button btn_confirm;
    PopupWindow popupWindow;
    LayoutInflater layoutInflater;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        txt_plate = (TextView)findViewById(R.id.txt_reportplate);
        txt_company = (TextView)findViewById(R.id.txt_reportcompany);
        txt_color = (TextView)findViewById(R.id.txt_reportcolor);
        txt_lot = (TextView)findViewById(R.id.txt_reportlotno);
        txt_spot = (TextView)findViewById(R.id.txt_reportspotno);
        txt_hours = (TextView)findViewById(R.id.txt_reporttotalhours);
        txt_amount = (TextView)findViewById(R.id.txt_reporttotalamount);
        txt_payment = (TextView)findViewById(R.id.txt_reportpayment);
        txt_date = (TextView)findViewById(R.id.txt_reportdatetime);
        btn_confirm = (Button)findViewById(R.id.btn_confirm);
        btn_confirm.setOnClickListener(this);
        relativeLayout = (RelativeLayout)findViewById(R.id.relative);


        SharedPreferences sp = getSharedPreferences("com.jk.thunder.shared", Context.MODE_PRIVATE);
       txt_plate.setText( sp.getString("CarPlate","Data Missing"));
        txt_company.setText(sp.getString("Company", "Data Missing"));
       txt_payment.setText( sp.getString("Payment", "Data Missing"));
       txt_lot.setText(sp.getString("Lot", "Data Missing"));
       txt_spot.setText(sp.getString("Spot", "Data Missing"));
         txt_date.setText(sp.getString("DateTime", "Data Missing"));
         txt_amount.setText(sp.getString("Amount", "Data Missing"));
        txt_color.setText(sp.getString("color", "Data Missing"));
        txt_hours.setText(sp.getString("totalhour", "Data Missing"));

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btn_confirm.getId()){
//            layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);
//            ViewGroup container = (ViewGroup) layoutInflater.inflate(R.layout.activity_popup,null);
//            popupWindow = new PopupWindow(container,800,800,true);
//            popupWindow.showAtLocation(relativeLayout, Gravity.NO_GRAVITY,500,500);
//
//            container.setOnTouchListener(new View.OnTouchListener() {
//                @Override
//                public boolean onTouch(View view, MotionEvent motionEvent) {
//                    popupWindow.dismiss();
//                    return true;
//                }
//            });
           // Toast.makeText(this," Receipt is Successfully Confirmed",Toast.LENGTH_LONG).show();
            Intent profileIntent = new Intent(this,HomeActivity.class);
            startActivity(profileIntent);
        }

    }
}
