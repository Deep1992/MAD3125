package com.example.master.parkingpanda;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText username;
    private EditText password;
    private Button login;
    private TextView register;
    DBParking dbHelper;
    SQLiteDatabase pandaDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        username = (EditText)findViewById(R.id.edtUserName);
        password = (EditText)findViewById(R.id.edtPassword);
        login = (Button)findViewById(R.id.btnLogin);
        login.setOnClickListener(this);
        register = (TextView)findViewById(R.id.txtRegistration);
        register.setOnClickListener(this);
        dbHelper = new DBParking(this);


    }



    @Override
    public void onClick(View view) {
            if(view.getId() == login.getId()){
                if(verifyLogin()){
                    SharedPreferences sp = getSharedPreferences("com.example.master.parkingpanda.shared", Context.MODE_PRIVATE);
                    SharedPreferences.Editor ed = sp.edit();
                    ed.putString("username",username.getText().toString());
                    ed.commit();
                    Intent homeIntent = new Intent(this,HomeActivity.class);
                    startActivity(homeIntent);

                }else{
                    Toast.makeText(this,"something wrong in password and username.Try Again",Toast.LENGTH_LONG).show();
                }

            }else if(view.getId() == register.getId()){
                Toast.makeText(this,
                        "Register Clicked",
                        Toast.LENGTH_SHORT).show();

                Intent registerIntent = new Intent
                        (this,RegisterActivity.class);
                startActivity(registerIntent);
            }

        }
        private boolean verifyLogin(){
        try{
            pandaDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email","Password"};
            Cursor cursor = pandaDB.query("UserInfo",columns,"Email = ? AND Password = ?",new String[]{username.getText().toString(),
            password.getText().toString()},null,null,null);
            if(cursor != null){
                if(cursor.getCount() > 0){
                    return true;
                }
            }
            return  false;


        }catch (Exception e){
            Log.e("LoginActivity","Something wrong with database connection");
            return false;

        }finally {
           pandaDB.close();
        }
        }
    }

