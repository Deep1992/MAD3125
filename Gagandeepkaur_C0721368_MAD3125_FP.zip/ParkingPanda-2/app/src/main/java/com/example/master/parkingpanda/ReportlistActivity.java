package com.example.master.parkingpanda;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ReportlistActivity extends AppCompatActivity {
    DBParking dbHelper;
    SQLiteDatabase pandaDB;
    Context context;

    ListView listView;
    ReportAdapter adapter;
    List<Product> mProductList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportlist);


        dbHelper = new DBParking(this);
        displayData();


    }

    private void displayData(){
        try{
            pandaDB = dbHelper.getReadableDatabase();
            String columns[] = {"Id","Carplatenumber","Carcompany","Carcolor","Noofhour","Lot","Spot","Datetime","Amount",
                    "Payment"};
            Cursor cursor = pandaDB.query("Receipt",columns,null,null,null,null,null);
            ListView listView = (ListView)findViewById(R.id.list_report);
            mProductList = new ArrayList<>();
            while (cursor.moveToNext()){
                mProductList.add(new Product(

                        cursor.getString(cursor.getColumnIndex("Carplatenumber")),
                        cursor.getString(cursor.getColumnIndex("Carcompany")),
                        cursor.getString(cursor.getColumnIndex("Carcolor")),
                        cursor.getString(cursor.getColumnIndex("Noofhour")),
                        cursor.getString(cursor.getColumnIndex("Lot")),
                        cursor.getString(cursor.getColumnIndex("Spot")),
                        cursor.getString(cursor.getColumnIndex("Datetime")),
                        cursor.getString(cursor.getColumnIndex("Amount")),

                        cursor.getString(cursor.getColumnIndex("Payment")),
                        cursor.getInt(cursor.getColumnIndex("Id"))));




            }
            adapter = new ReportAdapter(getApplicationContext(), mProductList);
            listView.setAdapter(adapter);
        }catch (Exception e){
            Log.e("ReceiptActivity",e.getMessage());
        }
        pandaDB.close();
    }


}
