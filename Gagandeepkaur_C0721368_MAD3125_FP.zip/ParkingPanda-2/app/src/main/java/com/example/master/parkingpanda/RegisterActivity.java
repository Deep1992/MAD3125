package com.example.master.parkingpanda;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edtname;
    private EditText edtemail;
    private EditText edtuserpassword;
    private EditText edtcontact;
    private EditText edtaddress;
    private EditText edtcity;
    private EditText edtcarplateNumber;
    private Button userRegister;
    private TextView txtuserLogin;
    DBParking dbHelper;
    SQLiteDatabase pandaDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edtname = (EditText)findViewById(R.id.edtUsername);
        edtemail = (EditText)findViewById(R.id.edtUserEmail);
        edtuserpassword = (EditText)findViewById(R.id.edtuserPassword);
        edtcontact = (EditText)findViewById(R.id.edtContact);
        edtaddress = (EditText) findViewById(R.id.edtAddress);
        edtcity= (EditText) findViewById(R.id.edtCity);
        edtcarplateNumber = (EditText) findViewById(R.id.edtCarPlateNumber);
        userRegister = (Button)findViewById(R.id.btnRegister);

        txtuserLogin = (TextView)findViewById(R.id.txtLogin);
        txtuserLogin.setOnClickListener(this);
        userRegister.setOnClickListener(this);
        dbHelper = new DBParking(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == userRegister.getId()){

            insertData();
            displayData();
            Intent loginintent = new Intent(this,LoginActivity.class);
            startActivity(loginintent);

        }else if(view.getId() == txtuserLogin.getId()){
            Intent loginintent = new Intent(this,LoginActivity.class);
            startActivity(loginintent);
        }
    }
    private void insertData(){
        String name = edtname.getText().toString();
        String email = edtemail.getText().toString();
        String userpassword = edtuserpassword.getText().toString();
        String contact = edtcontact.getText().toString();
        String address = edtaddress.getText().toString();
        String city = edtcity.getText().toString();
        String carplate = edtcarplateNumber.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Email",email);
        cv.put("Phone",contact);
        cv.put("Password",userpassword);
        cv.put("Address",address);
       cv.put("City",city);
        cv.put("Carplate",carplate);
        try{
           pandaDB = dbHelper.getWritableDatabase();
           pandaDB.insert("UserInfo",null,cv);
           Log.v("Insert record","Successful");
        }catch (Exception e){
            Log.e("Insert User",e.getMessage());
        }
        pandaDB.close();
    }
    private void displayData(){
        try{
            pandaDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Email","Phone","Password","Address","City","Carplate"};
            Cursor cursor = pandaDB.query("UserInfo",columns,null,null,null,null,null);
            while (cursor.moveToNext()){
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String contact = cursor.getString(cursor.getColumnIndex("Phone"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String address = cursor.getString(cursor.getColumnIndex("Address"));
                String city = cursor.getString(cursor.getColumnIndex("City"));
                String carplate = cursor.getString(cursor.getColumnIndex("Carplate"));
                String userInfo = name + "\n" + email + "\n" + contact + "\n" + password + "\n" + address
                   + "\n" + city + "\n" + carplate  ;
                Toast.makeText(this,"You are Successfully Registered",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            Log.e("RegisterActivity","Unable to fetch the records");
        }
        pandaDB.close();
    }
}
